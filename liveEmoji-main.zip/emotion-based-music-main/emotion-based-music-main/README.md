# emotion-based-music
<h1>Explaination Video</h1>
<a href="https://youtu.be/uDzLxos0lNU">Emotion based music | ai | deep learning project | with code | ml project</a>
<a href="https://youtu.be/uDzLxos0lNU"><img src="emotion.jpg"/></a>

<h1>Description</h1>
Welcome to new project emotion based music built by using mediapipe and keras. also opencv and streamlit is used to create a webapp. for capturing the webcam in the browser i used streamlit-webrtc module. I explained all of the code in this video which is required to create a webapp for emotion based music recommender.
<br><br>
In this video I used live emoji project code to create a model which could classify different emotions so I already explained the code for that which is over here
<br>Data Collection script : https://youtu.be/ZxZSGRdTLtE
<br>Data Training and Inference script : https://youtu.be/He_oZ-MnIrU
<br>code for live emoji : https://github.com/Pawandeep-prog/liveEmoji

<h1>Connect with me</h1>
If you have any queries regarding any of the topic I discussed in this video feel free to talk to e using below links:<br>
facebook : https://m.facebook.com/proogramminghub<br>
instagram : @programming_hut<br>
twitter : https://twitter.com/programming_hut<br>
github : https://github.com/Pawandeep-prog<br>
discord : https://discord.gg/G5Cunyg<br>
linkedin : https://www.linkedin.com/in/programminghut<br>
youtube : https://www.youtube.com/c/programminghutofficial<br>
